﻿
namespace SDA_Pr09_01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAddVertex = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbDeleteVertex = new System.Windows.Forms.ComboBox();
            this.btnDeleteVertex = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnDeleteEdge = new System.Windows.Forms.Button();
            this.btnAddEdge = new System.Windows.Forms.Button();
            this.listVertex2 = new System.Windows.Forms.ListBox();
            this.listVertex1 = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnShowMatrix = new System.Windows.Forms.Button();
            this.btnClearGraph = new System.Windows.Forms.Button();
            this.btnCreateGraph5 = new System.Windows.Forms.Button();
            this.btnCreateGraph4 = new System.Windows.Forms.Button();
            this.btnCreateGraph3 = new System.Windows.Forms.Button();
            this.btnCreateGraph2 = new System.Windows.Forms.Button();
            this.btnCreateGraph1 = new System.Windows.Forms.Button();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnTS = new System.Windows.Forms.Button();
            this.btnBFS = new System.Windows.Forms.Button();
            this.btnDFS = new System.Windows.Forms.Button();
            this.btnMST = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnAddVertex);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(233, 105);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Въвеждане на връх";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(24, 41);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(185, 20);
            this.textBox1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Име на върха";
            // 
            // btnAddVertex
            // 
            this.btnAddVertex.Location = new System.Drawing.Point(123, 67);
            this.btnAddVertex.Name = "btnAddVertex";
            this.btnAddVertex.Size = new System.Drawing.Size(86, 23);
            this.btnAddVertex.TabIndex = 0;
            this.btnAddVertex.Text = "Добави връх";
            this.btnAddVertex.UseVisualStyleBackColor = true;
            this.btnAddVertex.Click += new System.EventHandler(this.btnAddVertex_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cbDeleteVertex);
            this.groupBox2.Controls.Add(this.btnDeleteVertex);
            this.groupBox2.Location = new System.Drawing.Point(251, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(233, 105);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Изтриване на връх";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Име на върха";
            // 
            // cbDeleteVertex
            // 
            this.cbDeleteVertex.FormattingEnabled = true;
            this.cbDeleteVertex.Location = new System.Drawing.Point(24, 40);
            this.cbDeleteVertex.Name = "cbDeleteVertex";
            this.cbDeleteVertex.Size = new System.Drawing.Size(185, 21);
            this.cbDeleteVertex.TabIndex = 7;
            // 
            // btnDeleteVertex
            // 
            this.btnDeleteVertex.Location = new System.Drawing.Point(123, 67);
            this.btnDeleteVertex.Name = "btnDeleteVertex";
            this.btnDeleteVertex.Size = new System.Drawing.Size(86, 23);
            this.btnDeleteVertex.TabIndex = 6;
            this.btnDeleteVertex.Text = "Изтрии връх";
            this.btnDeleteVertex.UseVisualStyleBackColor = true;
            this.btnDeleteVertex.Click += new System.EventHandler(this.btnDeleteVertex_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnDeleteEdge);
            this.groupBox3.Controls.Add(this.btnAddEdge);
            this.groupBox3.Controls.Add(this.listVertex2);
            this.groupBox3.Controls.Add(this.listVertex1);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Location = new System.Drawing.Point(12, 123);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(233, 259);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ребро между два върха";
            // 
            // btnDeleteEdge
            // 
            this.btnDeleteEdge.Location = new System.Drawing.Point(122, 230);
            this.btnDeleteEdge.Name = "btnDeleteEdge";
            this.btnDeleteEdge.Size = new System.Drawing.Size(105, 23);
            this.btnDeleteEdge.TabIndex = 5;
            this.btnDeleteEdge.Text = "Изтрии ребро";
            this.btnDeleteEdge.UseVisualStyleBackColor = true;
            this.btnDeleteEdge.Click += new System.EventHandler(this.btnDeleteEdge_Click);
            // 
            // btnAddEdge
            // 
            this.btnAddEdge.Location = new System.Drawing.Point(122, 201);
            this.btnAddEdge.Name = "btnAddEdge";
            this.btnAddEdge.Size = new System.Drawing.Size(105, 23);
            this.btnAddEdge.TabIndex = 4;
            this.btnAddEdge.Text = "Добави ребро";
            this.btnAddEdge.UseVisualStyleBackColor = true;
            this.btnAddEdge.Click += new System.EventHandler(this.btnAddEdge_Click);
            // 
            // listVertex2
            // 
            this.listVertex2.FormattingEnabled = true;
            this.listVertex2.Location = new System.Drawing.Point(122, 58);
            this.listVertex2.Name = "listVertex2";
            this.listVertex2.Size = new System.Drawing.Size(105, 134);
            this.listVertex2.TabIndex = 3;
            // 
            // listVertex1
            // 
            this.listVertex1.FormattingEnabled = true;
            this.listVertex1.Location = new System.Drawing.Point(6, 58);
            this.listVertex1.Name = "listVertex1";
            this.listVertex1.Size = new System.Drawing.Size(105, 134);
            this.listVertex1.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(120, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Краен връх";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 33);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "Начален връх";
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox4.Controls.Add(this.richTextBox1);
            this.groupBox4.Location = new System.Drawing.Point(257, 123);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(308, 255);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Матрица на съседството";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(6, 19);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(296, 230);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.btnShowMatrix);
            this.groupBox5.Controls.Add(this.btnClearGraph);
            this.groupBox5.Controls.Add(this.btnCreateGraph5);
            this.groupBox5.Controls.Add(this.btnCreateGraph4);
            this.groupBox5.Controls.Add(this.btnCreateGraph3);
            this.groupBox5.Controls.Add(this.btnCreateGraph2);
            this.groupBox5.Controls.Add(this.btnCreateGraph1);
            this.groupBox5.Location = new System.Drawing.Point(565, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(129, 216);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            // 
            // btnShowMatrix
            // 
            this.btnShowMatrix.Location = new System.Drawing.Point(6, 188);
            this.btnShowMatrix.Name = "btnShowMatrix";
            this.btnShowMatrix.Size = new System.Drawing.Size(117, 23);
            this.btnShowMatrix.TabIndex = 6;
            this.btnShowMatrix.Text = "Покажи матрицата";
            this.btnShowMatrix.UseVisualStyleBackColor = true;
            this.btnShowMatrix.Click += new System.EventHandler(this.btnShowMatrix_Click);
            // 
            // btnClearGraph
            // 
            this.btnClearGraph.Location = new System.Drawing.Point(6, 159);
            this.btnClearGraph.Name = "btnClearGraph";
            this.btnClearGraph.Size = new System.Drawing.Size(117, 23);
            this.btnClearGraph.TabIndex = 5;
            this.btnClearGraph.Text = "Изтрии граф";
            this.btnClearGraph.UseVisualStyleBackColor = true;
            this.btnClearGraph.Click += new System.EventHandler(this.btnClearGraph_Click);
            // 
            // btnCreateGraph5
            // 
            this.btnCreateGraph5.Location = new System.Drawing.Point(6, 130);
            this.btnCreateGraph5.Name = "btnCreateGraph5";
            this.btnCreateGraph5.Size = new System.Drawing.Size(117, 23);
            this.btnCreateGraph5.TabIndex = 4;
            this.btnCreateGraph5.Text = "Създай граф 5";
            this.btnCreateGraph5.UseVisualStyleBackColor = true;
            // 
            // btnCreateGraph4
            // 
            this.btnCreateGraph4.Location = new System.Drawing.Point(6, 101);
            this.btnCreateGraph4.Name = "btnCreateGraph4";
            this.btnCreateGraph4.Size = new System.Drawing.Size(117, 23);
            this.btnCreateGraph4.TabIndex = 3;
            this.btnCreateGraph4.Text = "Създай граф 4";
            this.btnCreateGraph4.UseVisualStyleBackColor = true;
            // 
            // btnCreateGraph3
            // 
            this.btnCreateGraph3.Location = new System.Drawing.Point(6, 72);
            this.btnCreateGraph3.Name = "btnCreateGraph3";
            this.btnCreateGraph3.Size = new System.Drawing.Size(117, 23);
            this.btnCreateGraph3.TabIndex = 2;
            this.btnCreateGraph3.Text = "Създай граф 3";
            this.btnCreateGraph3.UseVisualStyleBackColor = true;
            this.btnCreateGraph3.Click += new System.EventHandler(this.btnCreateGraph3_Click);
            // 
            // btnCreateGraph2
            // 
            this.btnCreateGraph2.Location = new System.Drawing.Point(6, 43);
            this.btnCreateGraph2.Name = "btnCreateGraph2";
            this.btnCreateGraph2.Size = new System.Drawing.Size(117, 23);
            this.btnCreateGraph2.TabIndex = 1;
            this.btnCreateGraph2.Text = "Създай граф 2";
            this.btnCreateGraph2.UseVisualStyleBackColor = true;
            this.btnCreateGraph2.Click += new System.EventHandler(this.btnCreateGraph2_Click);
            // 
            // btnCreateGraph1
            // 
            this.btnCreateGraph1.Location = new System.Drawing.Point(6, 14);
            this.btnCreateGraph1.Name = "btnCreateGraph1";
            this.btnCreateGraph1.Size = new System.Drawing.Size(117, 23);
            this.btnCreateGraph1.TabIndex = 0;
            this.btnCreateGraph1.Text = "Създай граф 1";
            this.btnCreateGraph1.UseVisualStyleBackColor = true;
            this.btnCreateGraph1.Click += new System.EventHandler(this.btnCreateGraph1_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.btnTS);
            this.groupBox6.Controls.Add(this.btnBFS);
            this.groupBox6.Controls.Add(this.btnDFS);
            this.groupBox6.Controls.Add(this.btnMST);
            this.groupBox6.Location = new System.Drawing.Point(565, 219);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(129, 128);
            this.groupBox6.TabIndex = 5;
            this.groupBox6.TabStop = false;
            // 
            // btnTS
            // 
            this.btnTS.Location = new System.Drawing.Point(6, 10);
            this.btnTS.Name = "btnTS";
            this.btnTS.Size = new System.Drawing.Size(117, 23);
            this.btnTS.TabIndex = 10;
            this.btnTS.Text = "TS";
            this.btnTS.UseVisualStyleBackColor = true;
            this.btnTS.Click += new System.EventHandler(this.btnTS_Click);
            // 
            // btnBFS
            // 
            this.btnBFS.Location = new System.Drawing.Point(6, 68);
            this.btnBFS.Name = "btnBFS";
            this.btnBFS.Size = new System.Drawing.Size(117, 23);
            this.btnBFS.TabIndex = 8;
            this.btnBFS.Text = "BFS";
            this.btnBFS.UseVisualStyleBackColor = true;
            this.btnBFS.Click += new System.EventHandler(this.btnBFS_Click);
            // 
            // btnDFS
            // 
            this.btnDFS.Location = new System.Drawing.Point(6, 39);
            this.btnDFS.Name = "btnDFS";
            this.btnDFS.Size = new System.Drawing.Size(117, 23);
            this.btnDFS.TabIndex = 9;
            this.btnDFS.Text = "DFS";
            this.btnDFS.UseVisualStyleBackColor = true;
            this.btnDFS.Click += new System.EventHandler(this.btnDFS_Click);
            // 
            // btnMST
            // 
            this.btnMST.Location = new System.Drawing.Point(6, 97);
            this.btnMST.Name = "btnMST";
            this.btnMST.Size = new System.Drawing.Size(117, 23);
            this.btnMST.TabIndex = 7;
            this.btnMST.Text = "MST";
            this.btnMST.UseVisualStyleBackColor = true;
            this.btnMST.Click += new System.EventHandler(this.btnMST_Click);
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.Location = new System.Drawing.Point(571, 353);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(117, 23);
            this.btnClose.TabIndex = 11;
            this.btnClose.Text = "Изход";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 390);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.MinimumSize = new System.Drawing.Size(722, 429);
            this.Name = "Form1";
            this.Text = "SDA_46249z_Pr09_01";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAddVertex;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbDeleteVertex;
        private System.Windows.Forms.Button btnDeleteVertex;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnDeleteEdge;
        private System.Windows.Forms.Button btnAddEdge;
        private System.Windows.Forms.ListBox listVertex2;
        private System.Windows.Forms.ListBox listVertex1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button btnShowMatrix;
        private System.Windows.Forms.Button btnClearGraph;
        private System.Windows.Forms.Button btnCreateGraph5;
        private System.Windows.Forms.Button btnCreateGraph4;
        private System.Windows.Forms.Button btnCreateGraph3;
        private System.Windows.Forms.Button btnCreateGraph2;
        private System.Windows.Forms.Button btnCreateGraph1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnTS;
        private System.Windows.Forms.Button btnBFS;
        private System.Windows.Forms.Button btnDFS;
        private System.Windows.Forms.Button btnMST;
        private System.Windows.Forms.Button btnClose;
    }
}

