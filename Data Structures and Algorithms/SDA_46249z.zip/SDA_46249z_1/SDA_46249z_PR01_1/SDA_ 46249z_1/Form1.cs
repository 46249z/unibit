﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA__46249z_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonl_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] YourArray = { 1, 2, 3, 4, 5, 6 };
            string s = "";
            for (int i = 0; i < YourArray.Length; i++)
            {
                s += YourArray[i].ToString() + " ";
            }
                richTextBox1.Text= "Първоначално състояние на масива :\n" + s + "\n";


            // Създава се нов масив temp с един елемент /7 по-голям от масива YourArray, 
            int[] temp = new int[YourArray.Length + 1];
            if (YourArray != null)
            {
                Array.Copy(YourArray, temp,Math.Min(YourArray.Length, temp.Length));
            }
            // Масивът YourArray се пренасочва към масива temp. 
            YourArray = temp;
            // В последния елемент на преоразмерения масив YourArray // се добавя стойност.
            YourArray[YourArray.Length - 1] = 7;
            s = "";
               for (int i = 0; i < YourArray.Length; i++)
                {
                s += YourArray[i].ToString() + " ";
                }
            richTextBox1.Text +="Състояние на масива след преоразмеряването му:\n" + s;
        }

        private void button2_Click(object sender, EventArgs e)
        {
           

        }
    }
}
