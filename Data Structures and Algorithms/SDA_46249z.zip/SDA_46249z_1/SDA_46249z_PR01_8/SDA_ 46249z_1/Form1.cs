﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using System.Diagnostics;
namespace SDA__46249z_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }





        private void button1_Click(object sender, EventArgs e)

        {
            TimeSpan startingTime, duration;
            startingTime = new TimeSpan(0);
            duration = new TimeSpan(0);
            const int N = 1008;
            int[] nums = new int[N];

            for (int i = 0; i < N; i++)
            {
                nums[i] = i * i;
            }

            GC.Collect();

            GC.WaitForPendingFinalizers();
            startingTime = Process.GetCurrentProcess().UserProcessorTime;
            for (int i = 0; i <= nums.GetUpperBound(0); i++)
            {
                richTextBox1.Text += String.Format("arr[{0}] = {1}\n", i, nums[i]);
            }
            duration = Process.GetCurrentProcess().UserProcessorTime.Subtract(startingTime);
            richTextBox1.Text += String.Format("Общо време за изпълнение: {0}    секунди", duration.TotalSeconds);




        }

    }
}


        

