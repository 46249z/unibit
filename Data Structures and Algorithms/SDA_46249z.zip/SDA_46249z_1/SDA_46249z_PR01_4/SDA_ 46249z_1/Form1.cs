﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
namespace SDA__46249z_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        public class Intl6Collection : CollectionBase
        {
            public Int16 this[int index]
            {
                get 
                {
                    return ((Int16)List[index]);
                }
                set
                {
                    List[index] = value;
                }
            }

            public int Add(Int16 value)
            {
                return (List.Add(value));
            }

            public int Index0f(Int16 value)
            {
                return (List.IndexOf(value));
            }

            public void Insert(int index, Int16 value)
            {
                List.Insert(index, value);
            }
            public void Remove(Int16 value)
            {
                List.Remove(value);
            }
            public bool Contains(Int16 value)
            {
            // Ако стойността не е от тип Intl6,
            //ще върне false.
            return (List.Contains(value));
            }
        }
        // Използване на свойствата Count и Item.
        public string ShowIndexAndValues(Intl6Collection myCol)
        {
            string s ="";
            for (int i = 0; i < myCol.Count; i++)
            { 
            s += String.Format(" [{0}]: {1}\n",i,myCol[i]);
            }
            return s;
        }
        // Използва foreach декларация,
        // която скрива сложността на enumerator,
        // ЗАБЕЛЕЖКА: foreach е предпочитаният начин 
        // за изобразяване съдържанието на колекцията, 
        public string ShowValuesl(Intl6Collection myCol)
        {
            string s = "";
            foreach (Int16 i16 in myCol)
                {
                    s += String.Format("  {0}\n", i16);
                }
            return s;
        }
        // Използване на enumerator.
        public string ShowValues2(Intl6Collection myCol)
        {
            string s = "";
            System.Collections.IEnumerator myEnumerator = myCol.GetEnumerator();
            while (myEnumerator.MoveNext())
            { 
            s += String.Format("{0}\n", myEnumerator.Current);
            }
            return s;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Създаване и инициализиране // на нова колекция Collect.ionBase.
            Intl6Collection myI16 = new Intl6Collection();
            // Добавяне на елементи към колекцията.
            myI16.Add((Int16)1);
            myI16.Add((Int16)2);
            myI16.Add((Int16)3);
            myI16.Add((Int16)5);
            myI16.Add((Int16)7);

            // Показва съдържанието на колекцията 
            // като се използва цикъл foreach.
            // Това е предпочитаният метод.
            richTextBox1.Text = "Съдържание на колекцията (използва се foreach):\n";
            richTextBox1.Text += ShowValuesl(myI16);
            // Показва съдържанието на колекцията // като се използва enumerator.
            richTextBox1.Text += "Съдържание на колекцията (използва се enumerator):\n";
            richTextBox1.Text += ShowValues2(myI16);
            // Показва съдържанието на колекцията 
            // като се използват свойствата Count и Item. 
            richTextBox1.Text += "Първоначално съдържание на колекция¬та (използва се Count и Item);\n";

            richTextBox1.Text += ShowIndexAndValues(myI16);
            // Търсене в колекцията с Contains и indexQf, richTextBoxi.Text += String.Format("В колекцията има ли стойност 3? -	myI16.Contains(3));
            richTextBox1.Text += String.Format("Стойността 7 е в еле мент с индекс {0}.\n", myI16.Index0f(7));
            // Вмъкване на елемент в колекцията с индекс 3. 
            myI16.Insert(3, (Int16)12);
            richTextBox1.Text += "Съдържание на колекцията след доба вяне на индекс 3:\n";
            richTextBox1.Text += ShowIndexAndValues(myI16);
            // Вземане и задаване на стойността на елемент,
            // с помощта на индекс. 
            myI16[4] = 23;
            richTextBox1.Text +="Съдържание на колекцията след задаване на стойност 23 е индекс 4:\n";
            richTextBox1.Text += ShowIndexAndValues(myI16);
            // Изтриване на елемент от колекцията, 
            myI16.Remove((Int16) 2);
            // Показване на съдържанието на колекцията // чрез свойствата Count и Item.
            richTextBox1.Text += "Съдържание на колекцията след пре¬махване на елемент 2:\n";
            richTextBox1.Text += ShowIndexAndValues(myI16);
        }
    }
        
}
