﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PR_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double c;
            string str_a, str_b;
            str_a = textBox4.Text;
            str_b = textBox5.Text;
            try
            {
                c = Double.Parse(str_a) * Double.Parse(str_b);

                textBox6.Text = c.ToString();
            }
            catch (System.Exception err)
            {
                MessageBox.Show("Грешка във входните данни.\n"+" Моля въведете коректни данни. \n " + err);
            }

         }

        
    }
}
