﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_PR_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public struct EmployeeName
        {
            private string fname, mname, lname;
            public EmployeeName(string first, string middle, string last)
            {
                fname = first;
                mname = middle;
                lname = last;
            }
            public string firstName
            {
                get
                {
                    return fname;
                }
                set
                {
                    fname = firstName;
                }
            }
            public string middleName
            {
                get
                {
                    return mname;
                }
                set
                {
                    mname = middleName;
                }
            }
            public string lastName
            {
                get
                {
                    return lname;
                }
                set
                {
                    lname = lastName;
                }
            }
            public override string ToString()
            {
                return (String.Format("{0} {1} {2}", fname, mname, lname));
            }

            public string Initials()
            {
                return (String.Format("{0}{1}{2}", fname.Substring(0, 1), mname.Substring(0, 1), lname.Substring(0, 1)));
            }

            private void button1_Click(object sender, EventArgs e)
            {

            }



        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string first, middle, last;
            first = textBox4.Text;
            middle = textBox5.Text;
            last = textBox6.Text;
            EmployeeName myName = new EmployeeName(first, middle, last);
            string fullName, inits;
            fullName = myName.ToString();
            inits = myName.Initials();
            richTextBox1.Text = "Име на служителя => " + fullName + "\n";
            richTextBox1.Text += "Инициали на служителя => " + inits;
        }

    }
}
