﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
namespace SDA__46249z_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }





        private void button1_Click(object sender, EventArgs e)
        {
            DateTime startTime;
            TimeSpan endTime;
            const int N = 1000;
            int[] arr = new int[N];
            
            startTime = DateTime.Now; // Началното време 
            richTextBox1.Text += String.Format("Начало: {0}\n", startTime. ToString());
            // Начало на изследвания сегмент 
            for (int i=0; i < N; i++)
            {
                arr[i] = i * i;
                richTextBox1.Text += String.Format("arr[{0}] = {1}\n", i, arr[i]);
            }
            // Край на изследвания сегмент 
            // Определяне на интервала от време 
            endTime = DateTime. Now. Subtract (startTime);
            richTextBox1.Text +=   String.Format("Общо време за изпълнение: (0}\n", endTime.ToString());
        }
                     


    }

}


        

