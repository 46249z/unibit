﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_46249z_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

       

        class Hashing
        {
            public int SimpleHash(string s, string[] arr)
            {
                int total = 0;
                char[] cname;
                cname = s.ToCharArray();
                for (int i = 0; i < cname.Length; i++)
                {
                    total += (int)cname[i];
                }
                return total % arr.Length;
            }

            public string ShowDistrib(string[] arr)
            {
                string s = "";
                for (int i = 0; i < arr.Length; i++)
                {
                    if (arr[i] != null)
                    {
                        s += i.ToString() + "\t" + arr[i] + "\n";
                    }
                }
                return s;
            }
        }


        private void btRun_Click_1(object sender, EventArgs e)
        {
            Hashing h = new Hashing();
            string[] names = new string[10];
            string[] somelMames = new string[]
            {
            "Дебора Белчева", "Станил Петров","Калина Стефанова", "Кристина Йорданова","Филип Филипов",
            "Цветан Коларов", "Ива Аврамова","Христиан Данаилов", "Радена Трифонова","Емил Илиев", "Светослава Маджарова"
            };
            string name;
            int hashVal;
            richTextBox1.Text = "Обработените стойности са: \n";
            for (int i = 0; i < somelMames.Length; i++)
            {
                name = somelMames[i];
                hashVal = h.SimpleHash(name, names);
                richTextBox1.Text += "h (" + name + ") = " + hashVal.ToString() + "\n";
                names[hashVal] = name;
            }
            richTextBox1.Text += "\n Записаните стойности в масива са: \n";
            richTextBox1.Text += h.ShowDistrib(names);

        }
      
        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }

}