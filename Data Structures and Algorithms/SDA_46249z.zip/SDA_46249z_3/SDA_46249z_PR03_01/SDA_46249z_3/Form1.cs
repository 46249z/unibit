﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace SDA_46249z_3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        class CStack
        {
            private int p_index;
            private ArrayList list;
            public CStack()
            {
                list = new ArrayList();
                p_index = -1;
            }
            public int Count
            {
                get
                {
                    return list.Count;
                }
            }

            public void Push(object item)
            {
                list.Add(item);
                p_index++;
            }
            public object Pop()
            {
                object obj = list[p_index];
                list.RemoveAt(p_index);
                p_index--;
                return obj;
            }
            public void Clear()
            {
                list.Clear();
                p_index = -1;
            }
            public object Peek()
            {
                return list[p_index];
            }
        }








        private void button1_Click(object sender, EventArgs e)
        {
            CStack aList = new CStack();
            char chr;
            string ch;
            char dir;
            string word = "", wh = textBox1.Text;
            // Премахване на шпациите I 
            for (int i = 0; i < wh.Length; i++)
            {
                chr = wh[i];
                if (chr != ' ') word += chr;
            }
            if (word.Length > 2)
            {
                bool isPalindrome = true;
                for (int i = 0; i < word.Length; i++)
                    aList.Push(word.Substring(i, 1));
                int position = 0;
                while (aList.Count > 0)
                {
                    ch = aList.Pop().ToString();
                    if (ch != word.Substring(position, 1))
                    {
                        isPalindrome = false;
                        break;
                    }
                    position++;
                }
                if (isPalindrome)
                {
                    richTextBox1.Text += String.Format("'{0}' е палиндром.\n", wh);

                }
                else
                {
                    richTextBox1.Text += String.Format("'{0}'  не е палиндром.\n", wh);
                }

            }
            else
            {
                richTextBox1.Text += String.Format("Въведената дума има по малко от 3 символа.\n");
            }
        }
    }

}

              

               




    
