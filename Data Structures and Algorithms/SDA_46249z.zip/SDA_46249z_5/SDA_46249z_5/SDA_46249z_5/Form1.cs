﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_46249z_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        class TreeNode<T>
        {
            public T Element { get; set; }
            public TreeNode<T> Left { get; set; }
            public TreeNode<T> Right { get; set; }
            public TreeNode(T element)
            {
                this.Element = element;
            }

            public override string ToString()
            {
                string nodestring = "[" + this.Element + " ";
                // Няма наследници = Листо
                if (this.Left ==null && this.Right==null)
                {
                    nodestring += " (Листо) ";
                }
                if (this.Left!= null)
                {
                    nodestring += "Ляв: " + this.Left.ToString();
                }
                if (this.Right != null)
                {
                    nodestring += "Десен: " + this.Right.ToString();
                }
                nodestring += "] ";
                return nodestring;
            }
        }

        class BinarySearchTree<T>
        {
            public TreeNode<T> Root { get; set; }
            public BinarySearchTree()
            {
                this.Root = null;
            }
            public void Insert(T x)
            {
                this.Root = Insert(x, this.Root);
            }
            public void Remove(T x)
            {
                this.Root =Remove(x, this.Root);
            }

            public void RemoveMin()
            {
                this.Root = RemoveMin(this.Root);
            }
            public void RemoveMax()
            {
                this.Root = RemoveMax(this.Root);
            }
            public T FindMin()
            {
                return ElementAt(FindMin(this.Root));
            }
            public T FindMax()
            {
                return ElementAt(FindMax(this.Root));
            }

            public T Find(T x)
            {
                return ElementAt(Find(x, this.Root));
            }
            public void MakeEmpty()
            {
                this.Root = null;
            }
            public bool IsEmpty()
            {
                return this.Root == null;
            }
            private T ElementAt(TreeNode<T> t)
            {
                return t == null ? default(T) : t.Element;
            }

            private TreeNode<T> Find(T x, TreeNode<T> t)
            {
                while (t != null)
                {
                    if ((x as IComparable).CompareTo(t.Element)<0)
                    {
                        t= t.Left;
                    }
                    else if ((x as IComparable).CompareTo(t.Element)>0)
                    {
                        t = t.Right;
                    }
                    else
                    {
                        return t;
                    }
                }
                return null;
            }

            private TreeNode<T> FindMin(TreeNode<T> t)
            {
                if (t != null)
                {
                    while (t.Left != null)
                    {
                        t = t.Left;
                    }
                }
                return t;
            }       

            private TreeNode<T> FindMax(TreeNode<T> t)
            {
                if (t != null)
                {
                    while (t.Right !=null)
                    {
                        t = t.Right;
                    }
                }
                return t;
            }

            protected TreeNode<T> Insert(T x, TreeNode<T> t)
            {
                if (t == null)
                {
                    t = new TreeNode<T>(x);
                }
                else if ((x as IComparable).CompareTo(t.Element) < 0)
                {
                    t.Left = Insert(x, t.Left);
                }
                else if ((x as IComparable).CompareTo(t.Element) > 0)
                {
                    t.Right = Insert(x, t.Right);
                }
                else
                {
                    throw new Exception("");
                }
                return t;
            }

            protected TreeNode<T> RemoveMin(TreeNode<T> t)
            {
                if (t == null)
                {
                    throw new Exception("Елементът не е намерен");
                }
                else if (t.Left != null)
                {
                    t.Left= RemoveMin(t.Left);
                    return t;
                }
                else
                {
                    return t.Right;
                }
            }

            protected TreeNode<T> RemoveMax(TreeNode<T> t)
            {
                if (t == null)
                {
                    throw new Exception("Елементът не е намерен");
                }
                else if (t.Right != null)
                {
                    t.Right = RemoveMax(t.Right);
                    return t;
                }
                else
                {
                    return t.Left;
                }
            }

            protected TreeNode<T> Remove(T x, TreeNode<T> t)
            {
                if (t != null)
                {
                    throw new Exception("Елементът не е намерен");
                }
                else if ((x as IComparable).CompareTo(t.Element) < 0)
                {
                    t.Left = Remove(x, t.Left);
                }
                else if ((x as IComparable).CompareTo(t.Element) > 0)
                {
                    t.Right = Remove(x, t.Right);
                }
                else if (t.Left != null && t.Right != null)
                {
                    t.Element = FindMin(t.Right).Element;
                    t.Right = RemoveMin(t.Right);
                }
                else
                {
                    t = (t.Left != null) ? t.Left : t.Right;
                }
                return t;
            }
            public override string ToString()
            {
                return this.Root.ToString();
            }
        }

        BinarySearchTree<int> intTree = new BinarySearchTree<int>();
       






       


       


       



      



       


      




        

        private void btnRemove_Click_1(object sender, EventArgs e)
        {
            // Изтриване на елемент no зададена стойност 
            if (!intTree.IsEmpty())
            {
                int Value;

                if (int.TryParse(textValue.Text, out Value))
                {
                    intTree.Remove(Value);
                }
                btnTree_Click_1(sender, e);// Изобразяване на дървото
            }
            else richTextBox1.Text += String.Format("Дървото е празno \n");
            textValue.Text = "";
        }

        private void btnMakeEmpty_Click_1(object sender, EventArgs e)
        {
            // Изтрива дървото 
            intTree.MakeEmpty();
            btnTree_Click_1(sender, e);// Изобразяване на дървото
        }

        private void btnRandom_Click_1(object sender, EventArgs e)
        {
            Random r = new Random(DateTime.Now.Millisecond);
            string s = "";
            intTree.MakeEmpty();
            for (int i = 0; i < 8; i++)
            {
                int randomlnt = r.Next(1, 500);
                intTree.Insert(randomlnt);
                s += randomlnt + " ";
            }
            // Търсене на иай-гояямата стойност в дървото 
            richTextBox1.Text += String.Format("Haй големият елемент е: {0}\n", intTree.FindMax());
            // Търсене на най-малката стойност в дървото 
            richTextBox1.Text += String.Format("Най-малкият елемент е: {0}\n", intTree.FindMin());
            // Търсене на корена на дървото
            richTextBox1.Text += String.Format("Коренът е:	(0}\n", intTree.Root.Element);
            // Списък на въведените елементи в дървото 
            richTextBox1.Text += String.Format("Въведените елементи са:	{0}\n", 5);
            //Текстово представяне на дървото 
            richTextBox1.Text += String.Format("Дърво:	{0}\n", intTree);
        }

        private void btnRemoveMax_Click_1(object sender, EventArgs e)
        {
            // Изтриване на максималния елемент от дървото 
            if (!intTree.IsEmpty())
            {
                intTree.RemoveMax();
                btnTree_Click_1(sender, e);// Изобразяване на дървото
            }
            else richTextBox1.Text += String.Format("Дървото е празno \n");
        }

        private void btnRemoveMin_Click_1(object sender, EventArgs e)
        {
            // Изтриване на минималнния елемент or дървото 
            if (!intTree.IsEmpty())
            {
                intTree.RemoveMin();
                btnTree_Click_1(sender, e);// Изобразяване на дървото
            }
            else richTextBox1.Text += String.Format("Дървото е празno \n");
        }

        private void btnlnsert_Click_1(object sender, EventArgs e)
        {
            // Въвеждане на стойност (задължително int) 
            int Value;
            if (int.TryParse(textValue.Text, out Value))
            {
                intTree.Insert(Value);
                richTextBox1.Text += String.Format("Въведен елемент: {0}\n", Value);
            }
            else MessageBox.Show("Heвалиднa стойност");
            textValue.Text = "";
        }

        private void btnTree_Click_1(object sender, EventArgs e)
        {
            // Текстово представяне на дървото 
            if (!intTree.IsEmpty())
            {
                richTextBox1.Text += String.Format("Дърво:	{0}\n", intTree);
            }
            else richTextBox1.Text += String.Format("Дървото е празно\n");
        }

        private void btnFind_Click_1(object sender, EventArgs e)
        {
            // Търсене на елемент no зададена стойност 	// (задължително int)
            int Value, findValue;
            if (int.TryParse(textValue.Text, out Value))
            {
                findValue = intTree.Find(Value);
                if (findValue != 0)
                {
                    richTextBox1.Text += String.Format("Има елемент със стойност:	{0}\n", findValue);
                }
                else
                {
                    richTextBox1.Text += String.Format("Няма елемент със стойност:  {0}\n", Value);
                }
            }
            else MessageBox.Show("Невалидна стойност");
            textValue.Text = "";
        }

        private void btnFindMin_Click_1(object sender, EventArgs e)
        {
            // Търсене на най-малката стойност в дървото 
            if (!intTree.IsEmpty())
            {
                richTextBox1.Text += String.Format("Най - малкият елемент e: {0}\n", intTree.FindMin());
            }
            else richTextBox1.Text += String.Format("Дървото е празно\n");
        }

        private void btnRoot_Click_1(object sender, EventArgs e)
        {
            // Търсене на корена на дървото 
            if (intTree.IsEmpty())
            {
                richTextBox1.Text += String.Format("Коренът e: (0}\n", intTree.Root.Element);
            }
            else richTextBox1.Text += String.Format("Дървото е празно\n");
        }

        private void btnFindMax_Click_1(object sender, EventArgs e)
        {
            // Търсене на най-голямата стойност в дървото 
            if (!intTree.IsEmpty())
            {
                richTextBox1.Text += String.Format("Най - големият елемент е: {0}\n", intTree.FindMax());
            }
            else richTextBox1.Text += String.Format("Дървото е празно\n");
        }
    }

}