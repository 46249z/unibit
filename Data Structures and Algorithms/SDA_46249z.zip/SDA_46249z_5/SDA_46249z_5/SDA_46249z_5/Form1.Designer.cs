﻿namespace SDA_46249z_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.btnTree = new System.Windows.Forms.Button();
            this.textValue = new System.Windows.Forms.TextBox();
            this.btnRemove = new System.Windows.Forms.Button();
            this.btnMakeEmpty = new System.Windows.Forms.Button();
            this.btnRandom = new System.Windows.Forms.Button();
            this.btnRemoveMax = new System.Windows.Forms.Button();
            this.btnRemoveMin = new System.Windows.Forms.Button();
            this.btnlnsert = new System.Windows.Forms.Button();
            this.btnFind = new System.Windows.Forms.Button();
            this.btnFindMin = new System.Windows.Forms.Button();
            this.btnRoot = new System.Windows.Forms.Button();
            this.btnFindMax = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(1, 157);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(399, 148);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = "";
            // 
            // btnTree
            // 
            this.btnTree.Location = new System.Drawing.Point(12, 41);
            this.btnTree.Name = "btnTree";
            this.btnTree.Size = new System.Drawing.Size(100, 23);
            this.btnTree.TabIndex = 1;
            this.btnTree.Text = "Tree";
            this.btnTree.UseVisualStyleBackColor = true;
            this.btnTree.Click += new System.EventHandler(this.btnTree_Click_1);
            // 
            // textValue
            // 
            this.textValue.Location = new System.Drawing.Point(12, 12);
            this.textValue.Name = "textValue";
            this.textValue.Size = new System.Drawing.Size(366, 20);
            this.textValue.TabIndex = 2;
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(286, 70);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(92, 23);
            this.btnRemove.TabIndex = 3;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click_1);
            // 
            // btnMakeEmpty
            // 
            this.btnMakeEmpty.Location = new System.Drawing.Point(286, 99);
            this.btnMakeEmpty.Name = "btnMakeEmpty";
            this.btnMakeEmpty.Size = new System.Drawing.Size(92, 23);
            this.btnMakeEmpty.TabIndex = 4;
            this.btnMakeEmpty.Text = "MakeEmpty";
            this.btnMakeEmpty.UseVisualStyleBackColor = true;
            this.btnMakeEmpty.Click += new System.EventHandler(this.btnMakeEmpty_Click_1);
            // 
            // btnRandom
            // 
            this.btnRandom.Location = new System.Drawing.Point(286, 41);
            this.btnRandom.Name = "btnRandom";
            this.btnRandom.Size = new System.Drawing.Size(92, 23);
            this.btnRandom.TabIndex = 5;
            this.btnRandom.Text = "Random";
            this.btnRandom.UseVisualStyleBackColor = true;
            this.btnRandom.Click += new System.EventHandler(this.btnRandom_Click_1);
            // 
            // btnRemoveMax
            // 
            this.btnRemoveMax.Location = new System.Drawing.Point(152, 41);
            this.btnRemoveMax.Name = "btnRemoveMax";
            this.btnRemoveMax.Size = new System.Drawing.Size(103, 23);
            this.btnRemoveMax.TabIndex = 6;
            this.btnRemoveMax.Text = "RemoveMax";
            this.btnRemoveMax.UseVisualStyleBackColor = true;
            this.btnRemoveMax.Click += new System.EventHandler(this.btnRemoveMax_Click_1);
            // 
            // btnRemoveMin
            // 
            this.btnRemoveMin.Location = new System.Drawing.Point(152, 70);
            this.btnRemoveMin.Name = "btnRemoveMin";
            this.btnRemoveMin.Size = new System.Drawing.Size(103, 23);
            this.btnRemoveMin.TabIndex = 7;
            this.btnRemoveMin.Text = "RemoveMin";
            this.btnRemoveMin.UseVisualStyleBackColor = true;
            this.btnRemoveMin.Click += new System.EventHandler(this.btnRemoveMin_Click_1);
            // 
            // btnlnsert
            // 
            this.btnlnsert.Location = new System.Drawing.Point(152, 99);
            this.btnlnsert.Name = "btnlnsert";
            this.btnlnsert.Size = new System.Drawing.Size(103, 23);
            this.btnlnsert.TabIndex = 8;
            this.btnlnsert.Text = "Insert";
            this.btnlnsert.UseVisualStyleBackColor = true;
            this.btnlnsert.Click += new System.EventHandler(this.btnlnsert_Click_1);
            // 
            // btnFind
            // 
            this.btnFind.Location = new System.Drawing.Point(12, 70);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(100, 23);
            this.btnFind.TabIndex = 9;
            this.btnFind.Text = "Find";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click_1);
            // 
            // btnFindMin
            // 
            this.btnFindMin.Location = new System.Drawing.Point(12, 99);
            this.btnFindMin.Name = "btnFindMin";
            this.btnFindMin.Size = new System.Drawing.Size(100, 23);
            this.btnFindMin.TabIndex = 10;
            this.btnFindMin.Text = "FindMin";
            this.btnFindMin.UseVisualStyleBackColor = true;
            this.btnFindMin.Click += new System.EventHandler(this.btnFindMin_Click_1);
            // 
            // btnRoot
            // 
            this.btnRoot.Location = new System.Drawing.Point(12, 128);
            this.btnRoot.Name = "btnRoot";
            this.btnRoot.Size = new System.Drawing.Size(100, 23);
            this.btnRoot.TabIndex = 11;
            this.btnRoot.Text = "Root";
            this.btnRoot.UseVisualStyleBackColor = true;
            this.btnRoot.Click += new System.EventHandler(this.btnRoot_Click_1);
            // 
            // btnFindMax
            // 
            this.btnFindMax.Location = new System.Drawing.Point(152, 128);
            this.btnFindMax.Name = "btnFindMax";
            this.btnFindMax.Size = new System.Drawing.Size(103, 23);
            this.btnFindMax.TabIndex = 12;
            this.btnFindMax.Text = "FindMax";
            this.btnFindMax.UseVisualStyleBackColor = true;
            this.btnFindMax.Click += new System.EventHandler(this.btnFindMax_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 304);
            this.Controls.Add(this.btnFindMax);
            this.Controls.Add(this.btnRoot);
            this.Controls.Add(this.btnFindMin);
            this.Controls.Add(this.btnFind);
            this.Controls.Add(this.btnlnsert);
            this.Controls.Add(this.btnRemoveMin);
            this.Controls.Add(this.btnRemoveMax);
            this.Controls.Add(this.btnRandom);
            this.Controls.Add(this.btnMakeEmpty);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.textValue);
            this.Controls.Add(this.btnTree);
            this.Controls.Add(this.richTextBox1);
            this.Name = "Form1";
            this.Text = "SDA_46249z_PR05";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btnTree;
        private System.Windows.Forms.TextBox textValue;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnMakeEmpty;
        private System.Windows.Forms.Button btnRandom;
        private System.Windows.Forms.Button btnRemoveMax;
        private System.Windows.Forms.Button btnRemoveMin;
        private System.Windows.Forms.Button btnlnsert;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.Button btnFindMin;
        private System.Windows.Forms.Button btnRoot;
        private System.Windows.Forms.Button btnFindMax;
    }
}

