﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_46249z_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int[,] grades = new int[,]
            {
                { 3,	5,	2,	3,	6},
                { 4,	6,	3,	4,	5},
                { 5,	4,	4,	3,	4},
                {6, 4, 5, 5, 3}
            };
            int last_grade = grades.GetUpperBound( 1);
            double average = 0.0;
            int total;
            int last_student = grades.GetUpperBound(0);
            for (int row = 0; row <= last_student; row++)
            {
                total = 0;
                for (int col = 0; col <= last_grade; col++)
                {
                    total += grades[row, col];
                }
                average = (double)total / (double)(last_grade + 1);
                richTextBox1.Text += String.Format("Cpeдeн успех на студент: {0} => {1}\n", row + 1, average);

            }

        }
    }
}
