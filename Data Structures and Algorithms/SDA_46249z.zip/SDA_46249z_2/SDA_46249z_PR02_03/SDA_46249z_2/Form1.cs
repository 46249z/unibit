﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_46249z_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int sumNumForeach(params int[] args)
        {
            int sum = 0;
            foreach (int i in args)
                sum += i;
            return sum;
        }


        private int sumNumFor(params int[] args)
        {
            int sum = 0;
            for (int i=0; i<= args.GetUpperBound(0); i++)
                sum += args[i];
            return sum;
        }



        private void button1_Click(object sender, EventArgs e)
        {
            int[] grades = new int[] { 1,	2,	3 };
            int sum1;
            sum1= sumNumForeach(grades);
            richTextBox1.Text += String.Format("sumNumForeach (1,2,3)=> " + sum1 + "\n");
            grades = new int[] { 1, 2, 3, 4,5,6,7,8,9,10 };
            sum1 = sumNumForeach(grades);
            richTextBox1.Text += String.Format("sumNumForeach  (1,2,3,4,5,6,7,8,9,10)=> " + sum1 + "\n");
            grades = new int[] {  };
            sum1 = sumNumForeach(grades);
            richTextBox1.Text += String.Format("sumNumForeach ()=> " + sum1 + "\n\n");
            grades = new int[] { 1, 2, 3 };
            sum1 = sumNumFor(grades);
            richTextBox1.Text += String.Format("sumNumFor => " + sum1 + "\n");
            grades = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
            sum1 = sumNumFor(grades);
            richTextBox1.Text += String.Format("sumNumFor  (1,2,3,4,5,6,7,8,9,10)=> " + sum1 + "\n");
            grades = new int[] { };
            sum1 = sumNumFor(grades);
            richTextBox1.Text += String.Format("sumNumFor ()=> " + sum1 + "\n");


        }
    }
}
