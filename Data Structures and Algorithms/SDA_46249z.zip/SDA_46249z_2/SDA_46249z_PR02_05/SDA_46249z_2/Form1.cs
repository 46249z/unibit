﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace SDA_46249z_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string ViewSales(int[][] sales)
        {
            string s = "";
            for (int month = 0; month < 12; month++)
            {
                for (int day = 0; day < sales[month].GetUpperBound(0); day++)
                {
                    s += String.Format("month={0,2} day={1,3}\t sales={2}\n", month + 1, day + 1, sales[month][day]);
                }
                s += "*************************************************\n";
            }
            return s;
        }


        private void ShowArrayList1(object sender, ArrayList arr)
        {
            foreach (Object obarr in arr)
            {

                this.richTextBox1.Text += String.Format("Тип - {0} \t Стойност ={1}\n", obarr.GetType().ToString(), obarr.ToString());

            }
        }	
	



        private void ShowArrayLlst2(object sender, ArrayList arr, string title)
        {
            int position = 0;
            richTextBox1.Text+= String.Format("\n{0}: \n", title);
            foreach(Object obarr in arr)
            {
                richTextBox1.Text += String.Format("Позиция = (0) \t Стойност = {1}\n", position, obarr.ToString());
            }
        }








        private void button1_Click(object sender, EventArgs e)
        {
            ArrayList arr= new ArrayList();
            //добавяне на елементи чрез Add()
            arr.Add(95);
            arr.Add("Cофия");
            int position;
            position = arr.Add(12.3);
            richTextBox1.Text+=String.Format("Стойността {0} е добавена в позиция {1}\n",arr[position], position);
            ShowArrayList1(sender, arr);
            arr.Insert(1,111);
            arr.Insert(3,333);
            ShowArrayLlst2(sender, arr, "След добавяне на два елемента чрез Insert()\n");
            richTextBox1.Text+= String.Format("\n Текущият капацитет на масива е: {0}\n", arr.Capacity);
            richTextBox1.Text+= String.Format("Броят на използваните елементи в масива е: {0}\n", arr.Count);
            if (arr.Contains(111))
            {
                arr.Remove(111);
            }
            else
            {
                richTextBox1.Text += "Няма такъв обект в масива.\n";
            }
            ShowArrayLlst2(sender, arr, "След изтриване на един елемент чрез Contains()\n");
            arr.RemoveAt(2);
            ShowArrayLlst2(sender, arr, "След изтриване на един елемент чрез Removeat()\n");
            position = arr.IndexOf(95);
            if (position!=(-1))
            {
                arr.RemoveAt(position);
            }
            else
            {
                richTextBox1.Text +="Няма обект c такава стойност в масива.\n";
            }
            ShowArrayLlst2(sender, arr, "След изтриване на един елемент чрез indexof\n");



        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
