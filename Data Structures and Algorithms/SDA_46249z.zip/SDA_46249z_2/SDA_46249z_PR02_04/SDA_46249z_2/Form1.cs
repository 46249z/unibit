﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SDA_46249z_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string ViewSales(int[][] sales)
        {
            string s = "";
            for (int month = 0; month < 12; month++)
            {
                for (int day = 0; day < sales[month].GetUpperBound(0); day++)
                {
                    s += String.Format("month={0,2} day={1,3}\t sales={2}\n", month + 1, day + 1, sales[month][day]);
                }
                s += "*************************************************\n";
            }
            return s;
        }


        private string CalculateAverage(int[] [] sales)
        {
            string s = "";
            double total, average;
            for (int month = 0; month< 12; month++)
            {
                total = 0.0;
                for (int day = 0; day <= sales[month].GetUpperBound(0); day++)
                {
                    total += sales[month][day];
                }
                average = total / (sales[month].GetUpperBound(0) + 1);
                s += String.Format("month = {0,3}\t total = {1}\t average = {2:#.##}\n", month + 1, total, average);
            }
            return s;
        }

        private void RandomGenerateSales(int[][] sales)
        {
            Random rand = new Random();
            for (int month = 0; month < 12; month++)
            {
                for (int day = 0; day <= sales[month].GetUpperBound(0); day++)
                {
                    sales[month][day] = rand.Next(500, 1000);
                }
            }
        }




        private void button1_Click(object sender, EventArgs e)
        {
            //int[][] sales = new int[12][];

            int [] Jan= new int[31];
            int[] Feb = new int[29];
            int[] Mar = new int[31];
            int []	Apr = new int[30];            
            int[] May = new int[31];
            int[] Jun = new int[30];
            int[] Jul = new int[31];
            int[] Aug =  new int [31];
            int [] Sep = new int[30];
            int[] Oct	=new int[31];
            int[] Noe = new int[30];
            int[] Dec = new int[31];
            int [][] sales= new int[12][] {Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Noe, Dec };

            RandomGenerateSales(sales);
            richTextBox1.Text = ViewSales(sales);
            richTextBox1.Text += CalculateAverage(sales);



        }
    }
}
