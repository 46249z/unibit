package z46249.unibit.bg;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class IntroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        Button mainActivityBtn=findViewById(R.id.twoPlayers);
        mainActivityBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent startIntent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(startIntent);
            }
        });



        Button buttonSend = findViewById(R.id.buttonSend);
        buttonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendMail();
            }
        });

    }

    private void sendMail() {
        String recipient=findViewById(R.id.mailTo).toString();
        Intent intentMail = new Intent(Intent.ACTION_SEND);
        intentMail.putExtra(Intent.EXTRA_EMAIL,recipient);
        intentMail.setType("message/rfc822");
        startActivity(Intent.createChooser(intentMail, "Choose email client:"));
    }
}