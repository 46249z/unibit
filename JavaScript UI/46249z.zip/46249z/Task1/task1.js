function newColor() {
    //промяна на цвета на 10 h тага по id
    document.getElementById("h1").style.color = "red";
    document.getElementById("h2").style.color = "yellow";
    document.getElementById("h3").style.color = "purple";
    document.getElementById("h4").style.color = "pink";
    document.getElementById("h5").style.color = "green";
    document.getElementById("h11").style.color = "red";
    document.getElementById("h12").style.color = "yellow";
    document.getElementById("h13").style.color = "purple";
    document.getElementById("h14").style.color = "pink";
    document.getElementById("h15").style.color = "green";
}

function loadJS() {
    //добавяне на 5 реда
    var t1 = "— Ще бъдеш ли така добър да разкажеш една на Мечо Пух?";
    var t2 = "— Разбира се! — казах. — Какви приказки обича той?";
    var t3 = "— За себе си! Защото той е от този вид мечки.";
    var t4 = "— Да, виждам.";
    var t5 = "— И така, бъди добър…";
    document.getElementById("h11").innerHTML = t1;
    document.getElementById("h12").innerHTML = t2;
    document.getElementById("h13").innerHTML = t3;
    document.getElementById("h14").innerHTML = t4;
    document.getElementById("h15").innerHTML = t5;
    document.getElementById("btnJS").innerHTML = "Заредете още пет реда от книгата...";
}

