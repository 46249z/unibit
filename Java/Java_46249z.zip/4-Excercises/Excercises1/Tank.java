package Excercise2;

public class Tank {
    int level;
}
