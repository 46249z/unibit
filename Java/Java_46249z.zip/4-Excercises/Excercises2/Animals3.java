package EqualsExample;

class Animal0 {
    public void move() {
        System.out.println("Animals can move");
    }
}

class Dog0 extends Animal0 {
    public void move() {
        super.move();   // invokes the super class method
        System.out.println("Dogs can walk and run");
    }
}

 class TestDog0 {

    public static void main(String args[]) {
        Animal0 b = new Dog0();   // Animal reference but Dog object
        b.move();   // runs the method in Dog class
    }
}

class Animal3 {
    public void move() {
        System.out.println("Animals can move");
    }
}

class Dog3 extends Animal3 {
    public void move() {
        super.move();   // invokes the super class method
        System.out.println("Dogs can walk and run");
    }
}

 class TestDog30 {

    public static void main(String args[]) {
        Animal3 b = new Dog3();   // Animal reference but Dog object
        b.move();   // runs the method in Dog class
    }
}

