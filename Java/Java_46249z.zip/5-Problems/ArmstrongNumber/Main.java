package ArmstrongNumber;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Въведете число: ");
        int c=0,a,tmp;

        int number=Integer.parseInt(scan.nextLine());
        tmp=number;
        while(tmp>0)
        {
            a=tmp%10;
            tmp=tmp/10;
            c=c+(a*a*a);
        }
        if(number==c)
            System.out.println("Въведеното число: "+number + " е Армстронг число.");
        else
            System.out.println("Въведеното число: "+number +" не е Армстронг число.");
    }


}
