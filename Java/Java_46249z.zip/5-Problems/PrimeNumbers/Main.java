
package PrimeNumbers;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Въведете число: ");

                int number = Integer.parseInt(scan.nextLine());
                boolean isPrimeNumbers = false;
                for (int i = 2; i <= number / 2; ++i) {
                    // проверка дали чуслото е естествено
                    if (number % i == 0) {
                        isPrimeNumbers = true;
                        break;
                    }
                }

                if (!isPrimeNumbers)
                    System.out.println(number + " е есетствено число.");
                else
                    System.out.println(number + " не е есетствено число.");


    }
}
