package PalindromeString;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        String inputStr, reviStr = "";
        Scanner sc = new Scanner(System.in);

        System.out.print("Въведете текст:");
        inputStr = sc.nextLine();

        int length = inputStr.length();

        for ( int i = length - 1; i >= 0; i-- )
            reviStr = reviStr + inputStr.charAt(i);

        if (inputStr.equals(reviStr))
            System.out.println("Текстът: " +inputStr+" е палиндром");
        else
            System.out.println("Текстът: " +inputStr+" не е палиндром");    }
}
